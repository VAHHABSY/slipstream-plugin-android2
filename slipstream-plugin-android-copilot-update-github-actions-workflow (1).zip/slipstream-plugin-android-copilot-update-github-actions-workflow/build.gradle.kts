plugins {
    id("com.android.application") version "8.13.2" apply false
    id("com.github.ben-manes.versions") version "0.52.0"
    id("org.jetbrains.kotlin.android") version "2.3.0" apply false
    id("org.mozilla.rust-android-gradle.rust-android") version "0.9.6" apply false
}
